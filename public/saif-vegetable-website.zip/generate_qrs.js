const QRCode = require('qrcode');
const fs = require('fs');
const path = require('path');

const targets = [
  {
    name: 'qr_website_ios.png',
    text: 'https://ais-pre-y2nw5fuzaehiyzh3k2sxfw-712942562588.asia-east1.run.app',
    title: 'Website & iOS Apple Store Web App'
  },
  {
    name: 'qr_android_app.png',
    text: 'https://ais-pre-y2nw5fuzaehiyzh3k2sxfw-712942562588.asia-east1.run.app/saif-vegetable.apk',
    title: 'Android App Direct Download (APK)'
  },
  {
    name: 'qr_upi_pay.png',
    text: 'upi://pay?pa=8452953630@ptsbi&pn=Saif%20Vegetable&cu=INR',
    title: 'Saif Vegetable UPI Payment'
  }
];

const publicImgDir = path.join(__dirname, 'public', 'images');
const androidResDir = path.join(__dirname, 'app', 'src', 'main', 'res', 'drawable');

if (!fs.existsSync(publicImgDir)) fs.mkdirSync(publicImgDir, { recursive: true });
if (!fs.existsSync(androidResDir)) fs.mkdirSync(androidResDir, { recursive: true });

async function run() {
  for (const t of targets) {
    const pubPath = path.join(publicImgDir, t.name);
    const appPath = path.join(androidResDir, t.name);

    await QRCode.toFile(pubPath, t.text, {
      width: 512,
      margin: 2,
      color: {
        dark: '#144D2A', // Deep forest brand green
        light: '#FFFFFF'
      },
      errorCorrectionLevel: 'H'
    });

    fs.copyFileSync(pubPath, appPath);
    console.log(`Generated QR for ${t.title} -> ${pubPath} and ${appPath}`);
  }
}

run().catch(console.error);
